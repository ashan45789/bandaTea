/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author User
 */
public class model {
    package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateRecord {

    // Method to update product details
    public void updateProduct(String productCode, String newName, double newWsPrice, double newRetPrice) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection(); // Obtain database connection
            String query = "UPDATE product SET ProductName=?, WholesalePrice=?, RetailPrice=? WHERE ProductCode=?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, newName);
            pstmt.setDouble(2, newWsPrice);
            pstmt.setDouble(3, newRetPrice);
            pstmt.setString(4, productCode);
            
            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " rows updated."); // Optional: Print number of rows updated
            
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exception appropriately
        } finally {
            // Close resources in a finally block
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace(); // Handle exception appropriately
            }
        }
    }

    // Method to update customer details
    public void updateCustomer(String currentNIC, String newNIC, String newName, String newContact) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection(); // Obtain database connection
            String query = "UPDATE customer SET CustomerName=?, NIC=?, Contact=? WHERE NIC=?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, newName);
            pstmt.setString(2, newNIC);
            pstmt.setString(3, newContact);
            pstmt.setString(4, currentNIC);
            
            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " rows updated."); // Optional: Print number of rows updated
            
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exception appropriately
        } finally {
            // Close resources in a finally block
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace(); // Handle exception appropriately
            }
        }
    }

    // Method to update supplier details
    public void updateSupplier(String currentSupID, String newSupID, String newName, int newContact) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection(); // Obtain database connection
            String query = "UPDATE supplier SET SupplierName=?, SupplierID=?, SupplierContact=? WHERE SupplierID=?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, newName);
            pstmt.setString(2, newSupID);
            pstmt.setInt(3, newContact);
            pstmt.setString(4, currentSupID);
            
            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " rows updated."); // Optional: Print number of rows updated
            
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exception appropriately
        } finally {
            // Close resources in a finally block
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace(); // Handle exception appropriately
            }
        }
    }
}

    
}
