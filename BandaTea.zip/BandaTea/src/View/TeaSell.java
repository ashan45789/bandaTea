
package View;

import Controller.InsertController;
import Controller.LoginController;
import Model.DBConnection;
import Model.DBSearch;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TeaSell extends javax.swing.JFrame {

    public TeaSell() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        ProcodeTF = new javax.swing.JTextField();
        ProNameTF = new javax.swing.JTextField();
        QuntySP = new javax.swing.JSpinner();
        ProPriceTF = new javax.swing.JTextField();
        TotalTF = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        BillTableTD = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Total2TF = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        PayTF = new javax.swing.JTextField();
        BalanceLbl = new javax.swing.JLabel();
        BalanceTF = new javax.swing.JTextField();
        PayMethodCMB = new javax.swing.JComboBox<>();
        jLabel26 = new javax.swing.JLabel();
        PreviewBillBtn = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        LogOutBtn = new javax.swing.JButton();
        MinBtn = new javax.swing.JLabel();
        CloseBtn = new javax.swing.JLabel();
        AddBtn = new javax.swing.JButton();
        DeleteBtn = new javax.swing.JButton();
        ResetBtn = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setForeground(new java.awt.Color(0, 0, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(102, 255, 102));
        jPanel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel13.setText("Product Code");

        jLabel14.setText("Total");

        jLabel15.setText("Quantity");

        jLabel16.setText("Product Name");

        jLabel17.setText("Price");

        ProcodeTF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ProcodeTFKeyPressed(evt);
            }
        });

        ProNameTF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ProNameTFKeyPressed(evt);
            }
        });

        QuntySP.setValue(1);
        QuntySP.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                QuntySPStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ProcodeTF, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(ProNameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(QuntySP, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ProPriceTF, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TotalTF, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(ProcodeTF, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TotalTF, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ProPriceTF, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(QuntySP, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ProNameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(76, 76, 76))
        );

        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 480, 100));

        BillTableTD.setBorder(new javax.swing.border.MatteBorder(null));
        BillTableTD.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        BillTableTD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Code", "Product Name", "Quntity", "Unit Price", "Total"
            }
        ));
        jScrollPane1.setViewportView(BillTableTD);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, 722, 230));

        jPanel3.setBackground(new java.awt.Color(102, 255, 102));

        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Total");

        jLabel19.setBackground(new java.awt.Color(204, 204, 255));
        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 102));
        jLabel19.setText("Pay");

        BalanceLbl.setBackground(new java.awt.Color(204, 204, 255));
        BalanceLbl.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        BalanceLbl.setForeground(new java.awt.Color(0, 0, 102));
        BalanceLbl.setText("Balance");

        BalanceTF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                BalanceTFKeyPressed(evt);
            }
        });

        PayMethodCMB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cash", "Card", " " }));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 0, 102));
        jLabel26.setText("Payment Method");

        PreviewBillBtn.setText("Preview Bill");
        PreviewBillBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PreviewBillBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(PreviewBillBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PayMethodCMB, 0, 77, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Total2TF))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BalanceLbl)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(PayTF)
                            .addComponent(BalanceTF))))
                .addGap(18, 18, 18))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Total2TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PayTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BalanceLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BalanceTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PayMethodCMB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PreviewBillBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 40, -1, 170));

        jLabel8.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Fernando'S Super Market");
        jLabel8.setAlignmentX(0.5F);
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 360, 40));

        LogOutBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logouttea.jpg"))); // NOI18N
        LogOutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogOutBtnActionPerformed(evt);
            }
        });
        jPanel1.add(LogOutBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 60, 50));

        MinBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_minimize_window_24px_3.png"))); // NOI18N
        MinBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MinBtnMouseClicked(evt);
            }
        });
        jPanel1.add(MinBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 0, 30, 30));

        CloseBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_close_window_24px_1.png"))); // NOI18N
        CloseBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CloseBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CloseBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                CloseBtnMouseExited(evt);
            }
        });
        jPanel1.add(CloseBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 0, 30, 30));

        AddBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/add4.jpg"))); // NOI18N
        AddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddBtnActionPerformed(evt);
            }
        });
        jPanel1.add(AddBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 60, 50));

        DeleteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/delete.jpg"))); // NOI18N
        DeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBtnActionPerformed(evt);
            }
        });
        jPanel1.add(DeleteBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 60, 50));

        ResetBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/reset2.jpg"))); // NOI18N
        ResetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetBtnActionPerformed(evt);
            }
        });
        jPanel1.add(ResetBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 60, 50));

        jLabel9.setBackground(new java.awt.Color(0, 204, 51));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Background3.jpg"))); // NOI18N
        jLabel9.setText("BG");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 500));

        jTabbedPane1.addTab("Bill", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CloseBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseBtnMouseExited
        // TODO add your handling code here:
        //ColorChange(CloseBtn, new Color(0,51,255));
    }//GEN-LAST:event_CloseBtnMouseExited

    private void CloseBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseBtnMouseEntered
        // TODO add your handling code here:
        // ColorChange(CloseBtn, new Color(255,51,51));
    }//GEN-LAST:event_CloseBtnMouseEntered

    private void CloseBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseBtnMouseClicked
        // TODO add your handling code here:
      
    }//GEN-LAST:event_CloseBtnMouseClicked

    private void MinBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MinBtnMouseClicked
        // TODO add your handling code here:
       
        /* if(this.getExtendedState()!= Employee.MAXIMIZED_BOTH){
            this.setExtendedState(Employee.MAXIMIZED_BOTH);
        }
        else{
            this.setExtendedState(Employee.NORMAL);
        }*/
    }//GEN-LAST:event_MinBtnMouseClicked

    private void PreviewBillBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PreviewBillBtnActionPerformed
        // TODO add your handling code here:
        ViewBill view = new ViewBill();

        DefaultTableModel tbl = (DefaultTableModel)BillTableTD.getModel();
        view.BillTA.setText(view.BillTA.getText()+"==========================================================\n");
        view.BillTA.setText(view.BillTA.getText()+"---------------------------------Fernando's SuperMarket-----------------------------------\n");
        view.BillTA.setText(view.BillTA.getText()+"==========================================================\n");
        view.BillTA.setText(view.BillTA.getText()+"No"+"\t"+"Product"+"\t"+"Quantity"+"\t"+"Unit Price"+"\t"+"Total\n\n");

        for(int p = 0;p<BillTableTD.getRowCount(); p++){
            String PName = BillTableTD.getValueAt(p, 1).toString();
            int Qty = Integer.parseInt((String) BillTableTD.getValueAt(p, 2));
            String Uprice = BillTableTD.getValueAt(p, 3).toString();
            String Tprice = BillTableTD.getValueAt(p, 4).toString();
            view.BillTA.setText(view.BillTA.getText()+(p+1)+"\t"+PName+"\t"+Qty+"\t"+Uprice+"\t"+Tprice+"\n");
        }
        view.BillTA.setText(view.BillTA.getText()+"==========================================================\n");

        double Total = Double.parseDouble(Total2TF.getText());
        double Payment = Double.parseDouble(PayTF.getText());
        double Balance = Double.parseDouble(BalanceTF.getText());
        String PMethod = PayMethodCMB.getSelectedItem().toString();

        view.BillTA.setText(view.BillTA.getText()+"Total"+"\t\t\t\t"+Total+"\n");
        view.BillTA.setText(view.BillTA.getText()+"Pay"+"\t\t"+PMethod+"\t\t"+Payment+ "\n");
        view.BillTA.setText(view.BillTA.getText()+"Balance"+"\t\t\t\t"+Balance+"\n");
        view.BillTA.setText(view.BillTA.getText()+"==========================================================\n");
        view.BillTA.setText(view.BillTA.getText()+"\t\tTHANK YOU!\t\t\n");
        view.BillTA.setText(view.BillTA.getText()+"\t\tCOME AGAIN\t\t\n");
        view.BillTA.setText(view.BillTA.getText()+"==========================================================\n");

        view.BillTA.setEditable(false);
        view.setVisible(true);
    }//GEN-LAST:event_PreviewBillBtnActionPerformed

    private void BalanceTFKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_BalanceTFKeyPressed
        // TODO add your handling code here:
        double Total = Double.parseDouble(Total2TF.getText());
        double Pay = Double.parseDouble(PayTF.getText());
        double Balance = Pay - Total;
        BalanceTF.setText(String.valueOf(Balance));
    }//GEN-LAST:event_BalanceTFKeyPressed

    private void QuntySPStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_QuntySPStateChanged
        // TODO add your handling code here:
        double Qty =Double.parseDouble(QuntySP.getValue().toString());
        double prc =Double.parseDouble(ProPriceTF.getText());

        double total = Qty*prc;

        TotalTF.setText(String.valueOf(total));
        //Total2TF.setText(String.valueOf(total));
    }//GEN-LAST:event_QuntySPStateChanged

    private void ProNameTFKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProNameTFKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            String pname = ProNameTF.getText();
            try {

                String pcode = null; // initial value of the username
                double price; // initial value of the password

                ResultSet rs = new DBSearch().searchBillName(pname);

                if(rs.next() == false){

                    JOptionPane.showMessageDialog(this,"Product Note Found");
                }
                else{

                    pcode = rs.getString("ProductCode");
                    price = rs.getDouble("RetailPrice");
                    ProcodeTF.setText(pcode);
                    ProPriceTF.setText(String.valueOf(price));
                    TotalTF.setText(String.valueOf(price));
                }

                DBConnection.closeCon();
            }
            catch (SQLException ex) {
            }
        }
    }//GEN-LAST:event_ProNameTFKeyPressed

    private void ProcodeTFKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProcodeTFKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            String pcode = ProcodeTF.getText();
            try {

                String pname = null;
                double price;

                ResultSet rs = new DBSearch().searchBill(pcode);

                if(rs.next() == false){
                    JOptionPane.showMessageDialog(this,"Product Code Note Found");
                }
                else{

                    pname = rs.getString("ProductName"); //assign database login name to the variable
                    price = rs.getDouble("RetailPrice");//assign database password to the variable

                    ProNameTF.setText(pname);
                    ProPriceTF.setText(String.valueOf(price));
                    TotalTF.setText(String.valueOf(price));
                }

                DBConnection.closeCon();
            }
            catch (SQLException ex) {
            }
        }
    }//GEN-LAST:event_ProcodeTFKeyPressed

    private void LogOutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogOutBtnActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_LogOutBtnActionPerformed

    private void AddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddBtnActionPerformed
        // TODO add your handling code here:
        DefaultTableModel dtm = (DefaultTableModel)BillTableTD.getModel();
        if(ProcodeTF.getText().length()==0){
            JOptionPane.showMessageDialog(this,"Please Enter a product");
        }
        else{
            dtm.addRow(new Object[]{
                ProcodeTF.getText(),
                ProNameTF.getText(),
                QuntySP.getValue().toString(),
                ProPriceTF.getText(),
                TotalTF.getText()
            });
        }
        sum=0;
        for(int p = 0;p<BillTableTD.getRowCount(); p++){

            sum = sum + Double.parseDouble(BillTableTD.getValueAt(p, 4).toString());
        }
        Total2TF.setText(Double.toString(sum));
    }//GEN-LAST:event_AddBtnActionPerformed

    private void DeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBtnActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb = (DefaultTableModel)BillTableTD.getModel();
        int RowIndex = BillTableTD.getSelectedRow();
        if(RowIndex>=0){
            tb.removeRow(BillTableTD.getSelectedRow());
            sum=0;
            for(int p = 0;p<BillTableTD.getRowCount(); p++){

                sum = sum + Double.parseDouble(BillTableTD.getValueAt(p, 4).toString());
            }
            Total2TF.setText(Double.toString(sum));
        }
        else{
            JOptionPane.showMessageDialog(this,"Select a row ");
        }
    }//GEN-LAST:event_DeleteBtnActionPerformed

    private void ResetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetBtnActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb = (DefaultTableModel)BillTableTD.getModel();
        tb.setRowCount(0);
        ProcodeTF.setText("");
        ProNameTF.setText("");
        QuntySP.setValue(1);
        ProPriceTF.setText("");
        TotalTF.setText("");
        Total2TF.setText("");
        BalanceTF.setText("");
        PayTF.setText("");
        sum=0;
    }//GEN-LAST:event_ResetBtnActionPerformed
    
    public void ViewAllCustomers(){
        ResultSet r = new DBSearch().searchAllCustomers();
        ViewAllCustomers cust2 = new ViewAllCustomers();
        DefaultTableModel dtm = (DefaultTableModel)cust2.ViewAllCustTB.getModel();
        dtm.setRowCount(0);
        try{
            Vector V;
            while (r.next()){
                V = new Vector();
                V.add(r.getString("CustomerName"));
                V.add(r.getString("NIC"));
                V.add(r.getInt("Contact"));
                dtm.addRow(V);
            }
            DBConnection.closeCon();
        }
        catch (SQLException e){
        }

        cust2.setVisible(true);
        super.dispose();

    } 

    double sum = 0;
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TeaSell.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TeaSell.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TeaSell.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TeaSell.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TeaSell().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddBtn;
    private javax.swing.JLabel BalanceLbl;
    private javax.swing.JTextField BalanceTF;
    public javax.swing.JTable BillTableTD;
    private javax.swing.JLabel CloseBtn;
    private javax.swing.JButton DeleteBtn;
    private javax.swing.JButton LogOutBtn;
    private javax.swing.JLabel MinBtn;
    private javax.swing.JComboBox<String> PayMethodCMB;
    private javax.swing.JTextField PayTF;
    private javax.swing.JButton PreviewBillBtn;
    private javax.swing.JTextField ProNameTF;
    private javax.swing.JTextField ProPriceTF;
    private javax.swing.JTextField ProcodeTF;
    private javax.swing.JSpinner QuntySP;
    private javax.swing.JButton ResetBtn;
    private javax.swing.JTextField Total2TF;
    private javax.swing.JTextField TotalTF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    // End of variables declaration//GEN-END:variables
}
